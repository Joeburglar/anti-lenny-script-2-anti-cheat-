 local NoBind = { ----------------------------------------------Written By Joeburglar---------------------------
 "lua_openscript.cl lennyoffline.lua",
 "lua_openscript_cl lenny.lua",
 "lenny_wh 1",
 "lenny_wh_radius 99999",
 "lenny_wh 0",
 "lenny_esp 1",
 "lenny_aimsnap 1",
 "lenny_triggerbot 1",
 "lenny_rapidfire 1",
 "lenny_bhop 1",
 "lenny_namechange",
 "lenny_norecoil 1",
 "lenny_pkill",
 "lenny_printstaff",
 "lenny_triggerbot 1",
 "lenny_spam",
 "lenny_flashlightspam 1"
 }

 hook.Add( "PlayerBindPress", "BindPressCheckBlackList", function( ply, stringb, bouleanpress )	

 for i,v in pairs(NoBind) do
	if string.find(stringb,v) then
		net.Start("BlackListBindArctic")
		net.SendToServer()
	end
 end
 
 end)
 
 hook.Add( "Think", "NoNoonono", function()
	if (cvars.Number( "physgun_wheelspeed")) > 10 then
		RunConsoleCommand( "physgun_wheelspeed", "10" )
	end
 end)
