util.AddNetworkString( "BlackListBindArctic" )
	
net.Receive( "BlackListBindArctic", function( len, ply )
	ply:Kick( "The Use Of Cheats Are Not Tolerated!" )
end)